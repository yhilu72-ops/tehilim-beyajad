
v42:
- Reconstruida desde v40 estable.
- No reemplaza secciones viejas de forma peligrosa.
- Agrega una pantalla nueva #mis_reales para Mis salas reales.
- Redirige enlaces de Mis salas a #mis_reales.
- Restaura navegación normal y evita pantallas encimadas.

v43:
- Agrega banderas automáticas por país en tarjetas/pantallas.
- Reemplaza Seleccionar capítulos con grid real de 150 capítulos.
- Lee chapter_claims para bloquear capítulos claimed/completed.
- Permite tomar capítulos seleccionados y guardarlos en Supabase como claimed.
- Al tomar capítulos, asegura membership en room_members.

v44:
- Corrige banderas: México con acento ahora se detecta como 🇲🇽.
- La pantalla de capítulos distingue disponibles, tomados por mí, tomados por otros y completados.
- Agrega botón “Ya leí mis capítulos”.
- Actualiza status de claimed a completed en Supabase.

v45:
- Agrega progreso real de la sala.
- Lee chapter_claims completados para mostrar capítulos leídos.
- Muestra barra de progreso, porcentaje y texto “X de 150 capítulos leídos”.
- Si llega a 150, muestra “Tehilim completo”.

v46:
- Agrega Buenos deseos reales por sala.
- Pantalla #buenos_deseos.
- Publica deseo en tabla good_wishes.
- Muestra deseos de la sala.
- Permite publicar con nombre o anónimo.
Nota: requiere tabla good_wishes en Supabase.
