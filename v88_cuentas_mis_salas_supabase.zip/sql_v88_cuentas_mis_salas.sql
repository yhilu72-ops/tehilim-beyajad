
-- v88 soporte para cuentas, perfiles y salas por usuario
-- Ejecuta esto en Supabase SQL Editor solo si Perfil/Mis salas da errores de permisos o tabla.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  full_name text,
  country text default 'México',
  created_at timestamptz default now()
);

create table if not exists public.room_members (
  room_id uuid references public.rooms(id) on delete cascade,
  user_id uuid references auth.users(id) on delete cascade,
  role text default 'member',
  joined_at timestamptz default now(),
  primary key (room_id, user_id)
);

alter table public.profiles enable row level security;
alter table public.room_members enable row level security;

drop policy if exists "profiles_select_own" on public.profiles;
create policy "profiles_select_own"
on public.profiles for select
to authenticated
using (id = auth.uid());

drop policy if exists "profiles_insert_own" on public.profiles;
create policy "profiles_insert_own"
on public.profiles for insert
to authenticated
with check (id = auth.uid());

drop policy if exists "profiles_update_own" on public.profiles;
create policy "profiles_update_own"
on public.profiles for update
to authenticated
using (id = auth.uid())
with check (id = auth.uid());

drop policy if exists "room_members_select_own_or_room_creator" on public.room_members;
create policy "room_members_select_own_or_room_creator"
on public.room_members for select
to authenticated
using (
  user_id = auth.uid()
  or exists (
    select 1 from public.rooms r
    where r.id = room_members.room_id
      and r.creator_id = auth.uid()
  )
);

drop policy if exists "room_members_insert_self" on public.room_members;
create policy "room_members_insert_self"
on public.room_members for insert
to authenticated
with check (user_id = auth.uid());

drop policy if exists "room_members_delete_self_or_creator" on public.room_members;
create policy "room_members_delete_self_or_creator"
on public.room_members for delete
to authenticated
using (
  user_id = auth.uid()
  or exists (
    select 1 from public.rooms r
    where r.id = room_members.room_id
      and r.creator_id = auth.uid()
  )
);

-- Rooms: lectura pública de salas no borradas.
alter table public.rooms enable row level security;

drop policy if exists "rooms_select_public_or_member_or_creator" on public.rooms;
create policy "rooms_select_public_or_member_or_creator"
on public.rooms for select
to anon, authenticated
using (
  coalesce(deleted,false) = false
  and (
    access_type = 'public'
    or creator_id = auth.uid()
    or exists (
      select 1 from public.room_members m
      where m.room_id = rooms.id
        and m.user_id = auth.uid()
    )
  )
);

drop policy if exists "rooms_insert_creator" on public.rooms;
create policy "rooms_insert_creator"
on public.rooms for insert
to authenticated
with check (creator_id = auth.uid());

drop policy if exists "rooms_update_creator" on public.rooms;
create policy "rooms_update_creator"
on public.rooms for update
to authenticated
using (creator_id = auth.uid())
with check (creator_id = auth.uid());

grant usage on schema public to anon, authenticated;
grant select, insert, update on public.profiles to authenticated;
grant select, insert, delete on public.room_members to authenticated;
grant select on public.rooms to anon, authenticated;
grant insert, update on public.rooms to authenticated;
